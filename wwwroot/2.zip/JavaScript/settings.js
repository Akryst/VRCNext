﻿function addFileToList(f) {
    postedFiles.unshift(f);
    renderFileList();
}

function renderFileList() {
    const e = document.getElementById('fileList');
    if (!postedFiles.length) {
        e.innerHTML = `<div class="empty-msg">${t('relay.empty.posted_files', 'No files posted yet')}</div>`;
        return;
    }
    e.innerHTML = postedFiles.map((f, i) =>
        `<div class="file-row"><span class="file-name">${esc(f.name)}</span><span class="file-channel">${esc(f.channel)}</span><span class="file-size">${f.size}</span><span class="file-time">${f.time}</span><button class="file-del" onclick="deleteFile(${i})" title="${esc(t('common.delete', 'Delete'))}"><span class="msi" style="font-size:16px;">delete</span></button></div>`
    ).join('');
}

function deleteFile(i) {
    const f = postedFiles[i];
    if (f?.messageId) sendToCS({ action: 'deletePost', messageId: f.messageId, webhookUrl: f.webhookUrl });
}

function renderWebhookCards(w) {
    const e = document.getElementById('whCards'), s = (w || []).slice(0, 4);
    while (s.length < 4) s.push({});
    e.innerHTML = s.map((w, i) =>
        `<div class="wh-card"><div class="wh-top"><span class="wh-num">#${i + 1}</span><input class="vrcn-edit-field" id="whName${i}" value="${esc(w.Name || w.name || '')}" placeholder="${esc(tf('relay.webhook.channel_placeholder', { index: i + 1 }, `Channel ${i + 1}`))}" style="width:120px;"><label class="toggle"><input type="checkbox" id="whOn${i}" ${(w.Enabled || w.enabled) ? 'checked' : ''}><div class="toggle-track"><div class="toggle-knob"></div></div></label></div><input class="vrcn-edit-field" id="whUrl${i}" value="${esc(w.Url || w.url || '')}" placeholder="${esc(t('relay.webhook.url_placeholder', 'https://discord.com/api/webhooks/...'))}" style="width:100%;"></div>`
    ).join('');
}

function renderFolders(f) {
    const e = document.getElementById('folderList');
    if (!f || !f.length) {
        e.innerHTML = `<div class="folder-empty">${t('settings.watch_folders.empty', 'No folders added')}</div>`;
        return;
    }
    e.innerHTML = f.map((x, i) =>
        `<div class="folder-item" onclick="selectedFolderIdx=${i}" style="${selectedFolderIdx === i ? 'background:var(--bg-hover)' : ''}"><span>${esc(x)}</span><button class="folder-remove" onclick="event.stopPropagation();removeFolderAt(${i})" title="${esc(t('common.remove', 'Remove'))}"><span class="msi" style="font-size:16px;">close</span></button></div>`
    ).join('');
}

function addFolder() {
    sendToCS({ action: 'addFolder' });
}

function removeFolder() {
    if (selectedFolderIdx >= 0 && settings.folders?.[selectedFolderIdx]) {
        settings.folders.splice(selectedFolderIdx, 1);
        selectedFolderIdx = -1;
        renderFolders(settings.folders);
        autoSave();
    }
}

function removeFolderAt(i) {
    if (settings.folders) {
        settings.folders.splice(i, 1);
        selectedFolderIdx = -1;
        renderFolders(settings.folders);
        autoSave();
    }
}

function renderExtraExe(l) {
    const e = document.getElementById('extraExeList');
    if (!l || !l.length) {
        e.innerHTML = `<div class="folder-empty">${t('common.none', 'None')}</div>`;
        return;
    }
    e.innerHTML = l.map((x, i) =>
        `<div class="exe-item"><span>${esc(x.split(/[\\\\/]/).pop())}</span><button class="exe-remove" onclick="removeExtraExe(${i})" title="${esc(t('common.remove', 'Remove'))}"><span class="msi" style="font-size:16px;">close</span></button></div>`
    ).join('');
}

function browseExe(t) {
    sendToCS({ action: 'browseExe', target: t });
}

function removeExtraExe(i) {
    if (settings.extraExe) {
        settings.extraExe.splice(i, 1);
        renderExtraExe(settings.extraExe);
        autoSave();
    }
}

function saveSettings() {
    const w = [];
    for (let i = 0; i < 4; i++) {
        const nameEl = document.getElementById('whName' + i);
        const urlEl = document.getElementById('whUrl' + i);
        const onEl = document.getElementById('whOn' + i);
        w.push({
            Name: nameEl?.value || '',
            Url: urlEl?.value || '',
            Enabled: onEl?.checked || false
        });
    }
    const payload = {
        action: 'saveSettings',
        data: {
            botName: document.getElementById('setBotName').value,
            botAvatar: document.getElementById('setBotAvatar').value,
            webhooks: w,
            folders: settings.folders || [],
            vrcPath: document.getElementById('setVrcPath').value,
            extraExe: settings.extraExe || [],
            autoStart: false, // legacy â€” kept for JSON compat
            relayAutoStartVR:        document.getElementById('setAutoStartVR')?.checked       ?? false,
            relayAutoStartDesktop:   document.getElementById('setAutoStartDesktop')?.checked  ?? false,
            startWithWindows: document.getElementById('setStartWithWindows').checked,
            minimizeToTray: document.getElementById('setMinimizeToTray').checked,
            notifySound: false, // legacy â€” kept for JSON compat
            notifySoundEnabled: document.getElementById('setNotifySoundEnabled').checked,
            messageSoundEnabled: document.getElementById('setMessageSoundEnabled').checked,
            mediaRelaySoundEnabled: document.getElementById('setMediaRelaySoundEnabled').checked,
            steamOverlaySoundEnabled: document.getElementById('setSteamOverlaySoundEnabled')?.checked ?? true,
            language: currentLanguage,
            theme: currentTheme,
            specialTheme: currentSpecialTheme,
            autoColorAccuracy: autoColorAccuracy,
            playBtnTheme: currentPlayBtnTheme,
            cursorTheme: currentCursorTheme,
            guiZoom: Math.round(_guiZoom * 100),
            dashBgPath: dashBgPath,
            dashOpacity: parseInt(document.getElementById('setDashOpacity').value) || 40,
            randomDashBg: document.getElementById('setRandomBg').checked,
            clockEnabled: document.getElementById('setClockEnabled').checked,
            clockAmPm: document.getElementById('setClockAmPm').checked,
            vrcUsername: document.getElementById('setVrcUser').value,
            vrcPassword: document.getElementById('setVrcPass').value,
            sfMultiplier: parseFloat(document.getElementById('sfMultiplier').value) || 1,
            sfLockX: document.getElementById('sfLockX').checked,
            sfLockY: document.getElementById('sfLockY').checked,
            sfLockZ: document.getElementById('sfLockZ').checked,
            sfLeftHand: document.getElementById('sfLeftHand').checked,
            sfRightHand: document.getElementById('sfRightHand').checked,
            sfUseGrip: document.getElementById('sfUseGrip').checked,
            chatboxAutoStart: false, // legacy
            chatboxAutoStartVR:       document.getElementById('setCbAutoStartVR')?.checked        ?? false,
            chatboxAutoStartDesktop:  document.getElementById('setCbAutoStartDesktop')?.checked   ?? false,
            sfAutoStart: false, // legacy
            sfAutoStartVR:            document.getElementById('setSfAutoStartVR')?.checked        ?? false,
            ytAutoStartVR:            document.getElementById('setYtAutoStartVR')?.checked        ?? false,
            ytAutoStartDesktop:       document.getElementById('setYtAutoStartDesktop')?.checked   ?? false,
            vfAutoStartVR:            document.getElementById('setVfAutoStartVR')?.checked        ?? false,
            vfAutoStartDesktop:       document.getElementById('setVfAutoStartDesktop')?.checked   ?? false,
            discordPresenceAutoStart: false, // legacy
            dpAutoStartVR:            document.getElementById('setDpAutoStartVR')?.checked        ?? false,
            dpAutoStartDesktop:       document.getElementById('setDpAutoStartDesktop')?.checked   ?? false,
            vroAutoStart: false, // legacy
            vroAutoStartVR:           document.getElementById('setVroAutoStartVR')?.checked       ?? false,
            vroAttachLeft:   document.getElementById('vroAttachLeft')?.value === 'left',
            vroAttachHand:   document.getElementById('vroAttachPart')?.value === 'hand',
            vroPosX:  parseFloat(document.getElementById('vroPosX')?.value) || 0,
            vroPosY:  parseFloat(document.getElementById('vroPosY')?.value) || 0.07,
            vroPosZ:  parseFloat(document.getElementById('vroPosZ')?.value) || -0.05,
            vroRotX:  parseFloat(document.getElementById('vroRotX')?.value) || -80,
            vroRotY:  parseFloat(document.getElementById('vroRotY')?.value) || 0,
            vroRotZ:  parseFloat(document.getElementById('vroRotZ')?.value) || 0,
            vroWidth: parseFloat(document.getElementById('vroWidth')?.value) || 0.22,
            vroKeybind:        vroComboIds    ?? [],
            vroKeybindHand:    vroComboHand   ?? 0,
            vroKeybindDt:      vroDtIds       ?? [],
            vroKeybindDtHand:  vroDtHand      ?? 0,
            vroKeybindMode:    vroKeybindMode ?? 0,
            vroControlRadius:  parseInt(document.getElementById('vroControlRadius')?.value) || 28,
            vroToastEnabled:    !!document.getElementById('vroToastEnabled')?.checked,
            vroToastFavOnly:    !!document.getElementById('vroToastFavOnly')?.checked,
            vroToastSize:       parseInt(document.getElementById('vroToastSize')?.value) || 50,
            vroToastOffsetX:    parseFloat(document.getElementById('vroToastOffsetX')?.value) || 0,
            vroToastOffsetY:    parseFloat(document.getElementById('vroToastOffsetY')?.value) || -0.12,
            vroToastOnline:     !!document.getElementById('vroToastOnline')?.checked,
            vroToastOffline:    !!document.getElementById('vroToastOffline')?.checked,
            vroToastGps:        !!document.getElementById('vroToastGps')?.checked,
            vroToastStatus:     !!document.getElementById('vroToastStatus')?.checked,
            vroToastStatusDesc: !!document.getElementById('vroToastStatusDesc')?.checked,
            vroToastBio:        !!document.getElementById('vroToastBio')?.checked,
            vroToastDuration:   parseInt(document.getElementById('vroToastDuration')?.value) || 8,
            vroToastStack:      parseInt(document.getElementById('vroToastStack')?.value) || 2,
            vroToastFriendReq:  !!document.getElementById('vroToastFriendReq')?.checked,
            vroToastInvite:     !!document.getElementById('vroToastInvite')?.checked,
            vroToastGroupInv:   !!document.getElementById('vroToastGroupInv')?.checked,
            dpHideJoinBtnJoinMe: document.getElementById('dpHideJoinBtn_joinme')?.checked ?? false,
            dpHideJoinBtnOnline: document.getElementById('dpHideJoinBtn_online')?.checked ?? false,
            dpHideJoinBtnAskMe:  document.getElementById('dpHideJoinBtn_askme')?.checked  ?? false,
            dpHideJoinBtnBusy:   document.getElementById('dpHideJoinBtn_busy')?.checked   ?? false,
            dpHideInstIdJoinMe:  document.getElementById('dpHideInstId_joinme')?.checked ?? false,
            dpHideInstIdOnline:  document.getElementById('dpHideInstId_online')?.checked ?? false,
            dpHideInstIdAskMe:   document.getElementById('dpHideInstId_askme')?.checked  ?? false,
            dpHideInstIdBusy:    document.getElementById('dpHideInstId_busy')?.checked   ?? false,
            dpHideLocJoinMe:     document.getElementById('dpHideLoc_joinme')?.checked    ?? false,
            dpHideLocOnline:     document.getElementById('dpHideLoc_online')?.checked    ?? false,
            dpHideLocAskMe:      document.getElementById('dpHideLoc_askme')?.checked     ?? false,
            dpHideLocBusy:       document.getElementById('dpHideLoc_busy')?.checked      ?? false,
            dpHidePlayersJoinMe: document.getElementById('dpHidePlayers_joinme')?.checked ?? false,
            dpHidePlayersOnline: document.getElementById('dpHidePlayers_online')?.checked ?? false,
            dpHidePlayersAskMe:  document.getElementById('dpHidePlayers_askme')?.checked  ?? false,
            dpHidePlayersBusy:   document.getElementById('dpHidePlayers_busy')?.checked   ?? false,
            imgCacheEnabled:         document.getElementById('setImgCacheEnabled').checked,
            imgCacheLimitGb:         parseInt(document.getElementById('setImgCacheLimit').value) || 5,
            imgCacheOptimizeEnabled: document.getElementById('setImgCacheOptimizeEnabled').checked,
            ffcEnabled: document.getElementById('setFfcEnabled').checked,
            memoryTrimEnabled: document.getElementById('setMemoryTrimEnabled').checked,
            legacyWindow: document.getElementById('setLegacyWindow')?.checked ?? false,
            avtrdbReportDeleted: document.getElementById('setAvtrdbReport').checked,
            avtrdbSubmitAvatars: document.getElementById('setAvtrdbSubmit').checked,
            dashSectionOrder:  (typeof _dashLayout !== 'undefined') ? _dashLayout.order  : [],
            dashSectionHidden: (typeof _dashLayout !== 'undefined') ? _dashLayout.hidden : []
        }
    };
    // Sync in-memory flags immediately so sound functions see the updated value without waiting for round-trip
    settings.notifySoundEnabled      = payload.data.notifySoundEnabled;
    settings.messageSoundEnabled     = payload.data.messageSoundEnabled;
    settings.mediaRelaySoundEnabled  = payload.data.mediaRelaySoundEnabled;
    settings.steamOverlaySoundEnabled = payload.data.steamOverlaySoundEnabled;
    sendToCS(payload);
}

// Autosave: debounced save on any settings change
let _autoSaveTimer = null;
function autoSave() {
    clearTimeout(_autoSaveTimer);
    _autoSaveTimer = setTimeout(() => saveSettings(), 600);
}
// Attach autosave listeners after DOM ready
function initAutoSave() {
    const ids = ['setBotName','setBotAvatar','setVrcPath','setStartWithWindows','setMinimizeToTray',
        'setNotifySoundEnabled','setMessageSoundEnabled','setMediaRelaySoundEnabled','setSteamOverlaySoundEnabled',
        'setDashOpacity','setRandomBg','setClockEnabled','setClockAmPm',
        'setVrcUser','setVrcPass',
        'setAutoStartVR','setAutoStartDesktop',
        'setCbAutoStartVR','setCbAutoStartDesktop',
        'setSfAutoStartVR',
        'setYtAutoStartVR','setYtAutoStartDesktop',
        'setVfAutoStartVR','setVfAutoStartDesktop',
        'setDpAutoStartVR','setDpAutoStartDesktop',
        'setImgCacheEnabled','setImgCacheLimit','setImgCacheOptimizeEnabled','setMemoryTrimEnabled','setLegacyWindow'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        if (el.type === 'checkbox') el.addEventListener('change', autoSave);
        else if (el.type === 'range') el.addEventListener('input', autoSave);
        else el.addEventListener('input', autoSave);
    });
    // Webhook fields (4 slots x 3 fields)
    for (let i = 0; i < 4; i++) {
        ['whName','whUrl','whOn'].forEach(prefix => {
            const el = document.getElementById(prefix + i);
            if (!el) return;
            if (el.type === 'checkbox') el.addEventListener('change', autoSave);
            else el.addEventListener('input', autoSave);
        });
    }
}

function loadSettingsToUI(s) {
    settings = s;
    // Debug: log webhook data received from C#
    const wh = s.Webhooks || s.webhooks || [];
    console.log('[LOAD] Settings received. Webhooks:', JSON.stringify(wh));
    currentLanguage = normalizeUiLanguage((s.Language || s.language || currentLanguage || 'en').toLowerCase());
    renderLanguageChips();
    requestTranslation(currentLanguage);
    document.getElementById('setBotName').value = s.BotName || s.botName || '';
    document.getElementById('setBotAvatar').value = s.BotAvatarUrl || s.botAvatarUrl || '';
    document.getElementById('setVrcPath').value = s.VrcPath || s.vrcPath || '';
    document.getElementById('setVrcUser').value = s.VrcUsername || s.vrcUsername || '';
    document.getElementById('setVrcPass').value = s.VrcPassword || s.vrcPassword || '';
    const _asVR  = document.getElementById('setAutoStartVR');  if (_asVR)  _asVR.checked  = s.RelayAutoStartVR  ?? s.relayAutoStartVR  ?? false;
    const _asDT  = document.getElementById('setAutoStartDesktop'); if (_asDT) _asDT.checked = s.RelayAutoStartDesktop ?? s.relayAutoStartDesktop ?? false;
    document.getElementById('setStartWithWindows').checked = s.StartWithWindows || s.startWithWindows || false;
    document.getElementById('setMinimizeToTray').checked = s.MinimizeToTray ?? s.minimizeToTray ?? false;
    document.getElementById('setNotifySoundEnabled').checked = s.NotifySoundEnabled ?? s.notifySoundEnabled ?? false;
    document.getElementById('setMessageSoundEnabled').checked = s.MessageSoundEnabled ?? s.messageSoundEnabled ?? false;
    document.getElementById('setMediaRelaySoundEnabled').checked = s.MediaRelaySoundEnabled ?? s.mediaRelaySoundEnabled ?? false;
    settings.folders = s.WatchFolders || s.watchFolders || s.folders || [];
    settings.extraExe = s.ExtraExe || s.extraExe || [];
    settings.notifySoundEnabled = s.NotifySoundEnabled ?? s.notifySoundEnabled ?? false;
    settings.messageSoundEnabled = s.MessageSoundEnabled ?? s.messageSoundEnabled ?? false;
    settings.mediaRelaySoundEnabled = s.MediaRelaySoundEnabled ?? s.mediaRelaySoundEnabled ?? false;
    settings.steamOverlaySoundEnabled = s.SteamOverlaySoundEnabled ?? s.steamOverlaySoundEnabled ?? true;
    const _sovEl = document.getElementById('setSteamOverlaySoundEnabled');
    if (_sovEl) _sovEl.checked = settings.steamOverlaySoundEnabled;
    // Restore GUI zoom level
    const savedZoom = s.GuiZoom ?? s.guiZoom ?? 100;
    applyGuiZoom(savedZoom / 100);

    dashBgPath = s.DashBgPath || s.dashBgPath || '';
    if (typeof loadDashLayout === 'function') loadDashLayout({ order: s.DashSectionOrder || s.dashSectionOrder, hidden: s.DashSectionHidden || s.dashSectionHidden });
    dashOpacity = s.DashOpacity || s.dashOpacity || 40;
    document.getElementById('setDashOpacity').value = dashOpacity;
    document.getElementById('dashOpacityVal').textContent = dashOpacity + '%';
    const randomBg = s.RandomDashBg || s.randomDashBg || false;
    document.getElementById('setRandomBg').checked = randomBg;
    document.getElementById('setClockEnabled').checked = s.ClockEnabled ?? s.clockEnabled ?? true;
    document.getElementById('setClockAmPm').checked    = s.ClockAmPm    ?? s.clockAmPm    ?? false;
    applyClockSettings();
    if (randomBg) {
        // Request random image from watch folders
        sendToCS({ action: 'vrcRandomDashBg' });
    } else if (dashBgPath) {
        document.getElementById('dashBgName').textContent = dashBgPath.split(/[\\\\/]/).pop();
        sendToCS({ action: 'vrcLoadDashBg', path: dashBgPath });
    }
    renderWebhookCards((s.Webhooks || s.webhooks || []).slice(0, 4));
    renderFolders(settings.folders);
    renderExtraExe(settings.extraExe);
    updateFolderFilterOptions(settings.folders);
    currentTheme = s.Theme || s.theme || 'midnight';
    currentSpecialTheme = s.SpecialTheme || s.specialTheme || '';
    autoColorAccuracy = s.AutoColorAccuracy ?? s.autoColorAccuracy ?? 50;
    const accSlider = document.getElementById('setAutoAccuracy');
    if (accSlider) { accSlider.value = autoColorAccuracy; document.getElementById('autoAccuracyVal').textContent = autoColorAccuracy + '%'; }
    const accRow = document.getElementById('autoAccuracyRow');
    if (accRow) accRow.style.display = currentSpecialTheme === 'auto' ? 'flex' : 'none';
    if (THEMES[currentTheme]) applyColors(THEMES[currentTheme].c);
    else if (!currentTheme.startsWith('custom_')) { currentTheme = 'midnight'; applyColors(THEMES.midnight.c); }
    // custom_ themes are applied later when customColors loads
    renderThemeChips();
    renderSpecialThemeChips();
    currentPlayBtnTheme = s.PlayBtnTheme || s.playBtnTheme || '';
    applyPlayBtnTheme(currentPlayBtnTheme);
    _localHttpPort = s.LocalHttpPort || s.localHttpPort || 0;
    currentCursorTheme = s.CursorTheme || s.cursorTheme || '';
    sendToCS({ action: 'getCursorFiles' });

    // Restore chatbox settings
    document.getElementById('cbShowTime').checked = s.CbShowTime ?? s.cbShowTime ?? true;
    document.getElementById('cbShowMedia').checked = s.CbShowMedia ?? s.cbShowMedia ?? true;
    document.getElementById('cbShowPlaytime').checked = s.CbShowPlaytime ?? s.cbShowPlaytime ?? true;
    document.getElementById('cbShowCustom').checked = s.CbShowCustomText ?? s.cbShowCustomText ?? true;
    document.getElementById('cbShowSystemStats').checked = s.CbShowSystemStats ?? s.cbShowSystemStats ?? false;
    document.getElementById('cbShowAfk').checked = s.CbShowAfk ?? s.cbShowAfk ?? false;
    document.getElementById('cbAfkMessage').value = s.CbAfkMessage || s.cbAfkMessage || 'Currently AFK';
    document.getElementById('cbSuppressSound').checked = s.CbSuppressSound ?? s.cbSuppressSound ?? true;
    const cbAfkOn = s.CbShowAfk ?? s.cbShowAfk ?? false;
    document.getElementById('cbAfkCard').style.display = cbAfkOn ? '' : 'none';
    const cbTf = s.CbTimeFormat || s.cbTimeFormat || 'hh:mm tt';
    const cbTfEl = document.getElementById('cbTimeFormat');
    if (cbTfEl) cbTfEl.value = cbTf;
    const cbSep = s.CbSeparator || s.cbSeparator || ' | ';
    const cbSepEl = document.getElementById('cbSeparator');
    if (cbSepEl) cbSepEl.value = cbSep;
    const cbInt = s.CbIntervalMs || s.cbIntervalMs || 5000;
    const cbIntEl = document.getElementById('cbInterval');
    if (cbIntEl) cbIntEl.value = String(cbInt);
    chatboxCustomLines = s.CbCustomLines || s.cbCustomLines || [];
    renderChatboxLines();

    // Restore Space Flight settings
    document.getElementById('sfMultiplier').value = s.SfMultiplier ?? s.sfMultiplier ?? 1;
    document.getElementById('sfMultVal').textContent = (s.SfMultiplier ?? s.sfMultiplier ?? 1) + 'x';
    document.getElementById('sfLockX').checked = s.SfLockX ?? s.sfLockX ?? false;
    document.getElementById('sfLockY').checked = s.SfLockY ?? s.sfLockY ?? false;
    document.getElementById('sfLockZ').checked = s.SfLockZ ?? s.sfLockZ ?? false;
    document.getElementById('sfLeftHand').checked = s.SfLeftHand ?? s.sfLeftHand ?? false;
    document.getElementById('sfRightHand').checked = s.SfRightHand ?? s.sfRightHand ?? true;
    document.getElementById('sfUseGrip').checked = s.SfUseGrip ?? s.sfUseGrip ?? true;

    // Restore VR/Desktop auto-start flags
    const _set = (id, v) => { const el = document.getElementById(id); if (el) el.checked = !!v; };
    _set('setCbAutoStartVR',      s.ChatboxAutoStartVR      ?? s.chatboxAutoStartVR      ?? false);
    _set('setCbAutoStartDesktop', s.ChatboxAutoStartDesktop ?? s.chatboxAutoStartDesktop ?? false);
    _set('setSfAutoStartVR',      s.SfAutoStartVR           ?? s.sfAutoStartVR           ?? false);
    _set('setYtAutoStartVR',      s.YtAutoStartVR           ?? s.ytAutoStartVR           ?? false);
    _set('setYtAutoStartDesktop', s.YtAutoStartDesktop      ?? s.ytAutoStartDesktop      ?? false);
    _set('setVfAutoStartVR',      s.VfAutoStartVR           ?? s.vfAutoStartVR           ?? false);
    _set('setVfAutoStartDesktop', s.VfAutoStartDesktop      ?? s.vfAutoStartDesktop      ?? false);
    _set('setDpAutoStartVR',      s.DpAutoStartVR           ?? s.dpAutoStartVR           ?? false);
    _set('setDpAutoStartDesktop', s.DpAutoStartDesktop      ?? s.dpAutoStartDesktop      ?? false);
    // Restore Discord privacy + join button toggles
    const _dpPv = [
        ['dpHideInstId_joinme', 'DpHideInstIdJoinMe'],  ['dpHideInstId_online', 'DpHideInstIdOnline'],
        ['dpHideInstId_askme',  'DpHideInstIdAskMe'],   ['dpHideInstId_busy',   'DpHideInstIdBusy'],
        ['dpHideLoc_joinme',    'DpHideLocJoinMe'],     ['dpHideLoc_online',    'DpHideLocOnline'],
        ['dpHideLoc_askme',     'DpHideLocAskMe'],      ['dpHideLoc_busy',      'DpHideLocBusy'],
        ['dpHidePlayers_joinme','DpHidePlayersJoinMe'], ['dpHidePlayers_online','DpHidePlayersOnline'],
        ['dpHidePlayers_askme', 'DpHidePlayersAskMe'],  ['dpHidePlayers_busy',  'DpHidePlayersBusy'],
        ['dpHideJoinBtn_joinme','DpHideJoinBtnJoinMe'], ['dpHideJoinBtn_online','DpHideJoinBtnOnline'],
        ['dpHideJoinBtn_askme', 'DpHideJoinBtnAskMe'],  ['dpHideJoinBtn_busy',  'DpHideJoinBtnBusy'],
    ];
    for (const [id, key] of _dpPv) {
        const el = document.getElementById(id);
        if (el) el.checked = s[key] ?? s[key.charAt(0).toLowerCase() + key.slice(1)] ?? false;
    }

    // VR Overlay settings
    vroLoadSettings({
        vroAttachLeft: s.VroAttachLeft ?? s.vroAttachLeft ?? true,
        vroAttachHand: s.VroAttachHand ?? s.vroAttachHand ?? true,
        vroPosX: s.VroPosX ?? s.vroPosX ?? -0.10,
        vroPosY: s.VroPosY ?? s.vroPosY ?? -0.03,
        vroPosZ: s.VroPosZ ?? s.vroPosZ ?? 0.11,
        vroRotX: s.VroRotX ?? s.vroRotX ?? -180,
        vroRotY: s.VroRotY ?? s.vroRotY ?? 46,
        vroRotZ: s.VroRotZ ?? s.vroRotZ ?? 85,
        vroWidth: s.VroWidth ?? s.vroWidth ?? 0.16,
        vroAutoStartVR:      s.VroAutoStartVR      ?? s.vroAutoStartVR      ?? false,
        vroKeybind:       s.VroKeybind       ?? s.vroKeybind       ?? [],
        vroKeybindHand:   s.VroKeybindHand   ?? s.vroKeybindHand   ?? 0,
        vroKeybindDt:     s.VroKeybindDt     ?? s.vroKeybindDt     ?? [],
        vroKeybindDtHand: s.VroKeybindDtHand ?? s.vroKeybindDtHand ?? 0,
        vroKeybindMode:    s.VroKeybindMode   ?? s.vroKeybindMode   ?? 0,
        vroControlRadius:  s.VroControlRadius ?? s.vroControlRadius ?? 16,
        vroToastEnabled:    s.VroToastEnabled    ?? s.vroToastEnabled    ?? true,
        vroToastFavOnly:    s.VroToastFavOnly    ?? s.vroToastFavOnly    ?? false,
        vroToastSize:       s.VroToastSize       ?? s.vroToastSize       ?? 50,
        vroToastOffsetX:    s.VroToastOffsetX    ?? s.vroToastOffsetX    ?? 0,
        vroToastOffsetY:    s.VroToastOffsetY    ?? s.vroToastOffsetY    ?? -0.12,
        vroToastOnline:     s.VroToastOnline     ?? s.vroToastOnline     ?? true,
        vroToastOffline:    s.VroToastOffline    ?? s.vroToastOffline    ?? true,
        vroToastGps:        s.VroToastGps        ?? s.vroToastGps        ?? true,
        vroToastStatus:     s.VroToastStatus     ?? s.vroToastStatus     ?? true,
        vroToastStatusDesc: s.VroToastStatusDesc ?? s.vroToastStatusDesc ?? true,
        vroToastBio:        s.VroToastBio        ?? s.vroToastBio        ?? true,
        vroToastDuration:   s.VroToastDuration   ?? s.vroToastDuration   ?? 8,
        vroToastStack:      s.VroToastStack      ?? s.vroToastStack      ?? 2,
        vroToastFriendReq:  s.VroToastFriendReq  ?? s.vroToastFriendReq  ?? true,
        vroToastInvite:     s.VroToastInvite     ?? s.vroToastInvite     ?? true,
        vroToastGroupInv:   s.VroToastGroupInv   ?? s.vroToastGroupInv   ?? true,
    });
    // Auto-starts are now triggered by vrcLaunched (see messages.js)

    // Image cache settings
    const imgCacheEnabled         = s.ImgCacheEnabled         ?? s.imgCacheEnabled         ?? true;
    const imgCacheLimitGb         = Math.max(5, Math.min(30, s.ImgCacheLimitGb ?? s.imgCacheLimitGb ?? 5));
    const imgCacheOptimizeEnabled = s.ImgCacheOptimizeEnabled ?? s.imgCacheOptimizeEnabled ?? true;
    document.getElementById('setImgCacheEnabled').checked = imgCacheEnabled;
    document.getElementById('setImgCacheLimit').value = imgCacheLimitGb;
    document.getElementById('imgCacheLimitVal').textContent = imgCacheLimitGb + ' GB';
    document.getElementById('setImgCacheOptimizeEnabled').checked = imgCacheOptimizeEnabled;
    updateImgCacheUi();

    // Fast Fetch Cache
    document.getElementById('setFfcEnabled').checked = s.FfcEnabled ?? s.ffcEnabled ?? true;

    // Avtrdb Support
    document.getElementById('setAvtrdbReport').checked = s.AvtrdbReportDeleted ?? s.avtrdbReportDeleted ?? true;
    document.getElementById('setAvtrdbSubmit').checked = s.AvtrdbSubmitAvatars ?? s.avtrdbSubmitAvatars ?? false;

    // Memory Trim
    document.getElementById('setMemoryTrimEnabled').checked = s.MemoryTrimEnabled ?? s.memoryTrimEnabled ?? false;

    // Legacy Window
    const legacyWindow = s.LegacyWindow ?? s.legacyWindow ?? false;
    const lwEl = document.getElementById('setLegacyWindow');
    if (lwEl) lwEl.checked = legacyWindow;
    const winDotsEl = document.querySelector('.win-dots');
    if (winDotsEl) winDotsEl.style.display = legacyWindow ? 'none' : '';
    const legacyHint = document.getElementById('legacyRestartHint');
    if (legacyHint) legacyHint.style.display = 'none';
    window._legacyWindow = legacyWindow;

    // Sync custom dropdowns to reflect programmatically set values
    document.querySelectorAll('select').forEach(s => s._vnRefresh && s._vnRefresh());

    // Setup autosave listeners after UI is populated
    setTimeout(initAutoSave, 100);
}

function updateImgCacheUi() {
    const enabled = document.getElementById('setImgCacheEnabled').checked;
    document.getElementById('imgCacheLimitRow').style.display = enabled ? '' : 'none';
    if (enabled) sendToCS({ action: 'getImgCacheSize' });
}

function updateImgCacheSizeBar(bytes) {
    const el = document.getElementById('imgCacheSizeBar');
    const label = document.getElementById('imgCacheSizeLabel');
    if (!el || !label) return;
    const limitGb = parseInt(document.getElementById('setImgCacheLimit').value) || 5;
    const limitBytes = limitGb * 1024 * 1024 * 1024;
    const pct = Math.min(100, (bytes / limitBytes) * 100);
    el.style.width = pct + '%';
    const mb = bytes / (1024 * 1024);
    label.textContent = mb >= 1024
        ? (mb / 1024).toFixed(2) + ' GB used'
        : mb.toFixed(1) + ' MB used';
}

function startForceOptimize() {
    const btn = document.getElementById('btnForceOptimize');
    if (btn) btn.disabled = true;
    sendToCS({ action: 'optimizeImgCache' });
}

function handleImgCacheOptimizeProgress(data) {
    const wrap  = document.getElementById('imgOptimizeProgress');
    const bar   = document.getElementById('imgOptimizeBar');
    const label = document.getElementById('imgOptimizeLabel');
    const btn   = document.getElementById('btnForceOptimize');
    if (!wrap || !bar || !label) return;

    // done = -1 signals completion
    if (data.done === -1) {
        wrap.style.display = 'none';
        bar.style.width = '0%';
        if (btn) btn.disabled = false;
        return;
    }

    wrap.style.display = '';
    if (data.total > 0) {
        const pct = Math.round((data.done / data.total) * 100);
        bar.style.width = pct + '%';
        label.textContent = `Optimizing… ${data.done} / ${data.total} (${pct}%)`;
    } else {
        bar.style.width = '0%';
        label.textContent = 'Scanning…';
    }
}

// ── Legacy Window (Debugging) ──────────────────────────────────────────────
function onLegacyWindowChange() {
    autoSave();
    const hint = document.getElementById('legacyRestartHint');
    if (hint) hint.style.display = '';
}

// ── Text Tools (Debugging) ─────────────────────────────────────────────────
let _textToolsEnabled = false;

function toggleTextTools(enabled) {
    _textToolsEnabled = enabled;
    document.documentElement.classList.toggle('text-tools-active', enabled);
}

// â”€â”€ VRCX Import â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

let _vrcxPreviewData = null;
let _vrcxLastProgress = null;
let _vrcxLastDone = null;
let _vrcxLastError = null;

function settingsUiLocale() {
    return getLanguageLocale();
}

function formatSettingsNumber(value) {
    return Number(value ?? 0).toLocaleString(settingsUiLocale());
}

function vrcxSelectBtnHtml(selecting = false) {
    return selecting
        ? `<span class="msi" style="font-size:16px;">hourglass_empty</span> ${t('settings.vrcx.selecting', 'Selecting...')}`
        : `<span class="msi" style="font-size:16px;">storage</span> ${t('settings.vrcx.select_db', 'Select VRCX Database')}`;
}

function vrcxStartBtnHtml(retry = false) {
    return retry
        ? `<span class="msi" style="font-size:16px;">upload</span> ${t('settings.vrcx.retry_import', 'Retry Import')}`
        : `<span class="msi" style="font-size:16px;">upload</span> ${t('settings.vrcx.start_import', 'Start Import')}`;
}

function translateVrcxStatus(status) {
    switch (status) {
        case 'Reading database...':
            return t('settings.vrcx.progress.reading_database', 'Reading database...');
        case 'Reading friend data...':
            return t('settings.vrcx.progress.reading_friend_data', 'Reading friend data...');
        case 'Reading timeline events...':
            return t('settings.vrcx.progress.reading_timeline_events', 'Reading timeline events...');
        case 'Reading friend events...':
            return t('settings.vrcx.progress.reading_friend_events', 'Reading friend events...');
        case 'Generating meet events...':
            return t('settings.vrcx.progress.generating_meet_events', 'Generating meet events...');
        case 'Merging into VRCNext...':
            return t('settings.vrcx.progress.merging', 'Merging into VRCNext...');
        case 'Saving timeline...':
            return t('settings.vrcx.progress.saving_timeline', 'Saving timeline...');
        case 'Done':
            return t('common.done', 'Done');
        default:
            return status || '';
    }
}

function renderVrcxPreviewRows(p) {
    const rows = [
        [t('settings.vrcx.preview.worlds_tracked', 'Worlds tracked'), p.worlds],
        [t('settings.vrcx.preview.location_visits', 'Location visits'), p.locations],
        [t('settings.vrcx.preview.friends_time', 'Friends (time)'), p.friendTimes],
        [t('settings.vrcx.preview.gps_events', 'GPS events'), p.gps],
        [t('settings.vrcx.preview.online_offline', 'Online / Offline'), p.onlineOffline],
        [t('settings.vrcx.preview.status_changes', 'Status changes'), p.statuses],
        [t('settings.vrcx.preview.bio_changes', 'Bio changes'), p.bios],
    ];
    document.getElementById('vrcxPreviewRows').innerHTML = rows.map(([label, val]) =>
        `<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 8px;background:var(--bg-input);border-radius:6px;">
            <span style="font-size:12px;opacity:.7;">${esc(label)}</span>
            <span style="font-size:12px;font-weight:600;">${formatSettingsNumber(val)}</span>
        </div>`
    ).join('');
}

function renderVrcxSuccessDetail(p) {
    const el = document.getElementById('vrcxSuccessDetail');
    if (!el) return;
    el.textContent = tf('settings.vrcx.success.summary', {
        worlds: formatSettingsNumber(p.worlds),
        friends: formatSettingsNumber(p.friends),
        joins: formatSettingsNumber(p.timelineJoins),
        friend_events: formatSettingsNumber(p.friendEvents),
        meets: formatSettingsNumber(p.meetEvents),
    }, `${formatSettingsNumber(p.worlds)} worlds, ${formatSettingsNumber(p.friends)} friends, ${formatSettingsNumber(p.timelineJoins)} joins, ${formatSettingsNumber(p.friendEvents)} friend events, ${formatSettingsNumber(p.meetEvents)} meets`);
}

function renderVrcxError(err) {
    const el = document.getElementById('vrcxImportError');
    if (!el) return;
    el.textContent = tf('settings.vrcx.error.message', {
        error: err || t('settings.vrcx.error.unknown', 'Unknown error'),
    }, `Error: ${err || 'Unknown error'}`);
}

function vrcxSelectFile() {
    const btn = document.getElementById('vrcxSelectBtn');
    btn.disabled = true;
    btn.innerHTML = vrcxSelectBtnHtml(true);
    sendToCS({ action: 'importVrcxSelect' });
}

function vrcxReset() {
    _vrcxPreviewData = null;
    _vrcxLastProgress = null;
    _vrcxLastDone = null;
    _vrcxLastError = null;
    document.getElementById('vrcxPreviewBox').style.display = 'none';
    document.getElementById('vrcxProgressWrap').style.display = 'none';
    document.getElementById('vrcxSuccessCard').style.display = 'none';
    document.getElementById('vrcxImportError').style.display = 'none';
    document.getElementById('vrcxActionBtns').style.display = 'flex';
    document.getElementById('vrcxDoneBtn').style.display = 'none';
    const btn = document.getElementById('vrcxSelectBtn');
    btn.style.display = '';
    btn.disabled = false;
    btn.innerHTML = vrcxSelectBtnHtml(false);
    const start = document.getElementById('vrcxStartBtn');
    start.disabled = false;
    start.innerHTML = vrcxStartBtnHtml(false);
}

function vrcxShowPreview(p) {
    _vrcxPreviewData = p;
    _vrcxLastProgress = null;
    _vrcxLastDone = null;
    _vrcxLastError = null;
    document.getElementById('vrcxSelectBtn').style.display = 'none';
    document.getElementById('vrcxFileName').textContent = p.path || 'VRCX.sqlite3';
    renderVrcxPreviewRows(p);
    document.getElementById('vrcxProgressWrap').style.display = 'none';
    document.getElementById('vrcxSuccessCard').style.display = 'none';
    document.getElementById('vrcxImportError').style.display = 'none';
    document.getElementById('vrcxActionBtns').style.display = 'flex';
    document.getElementById('vrcxDoneBtn').style.display = 'none';
    const start = document.getElementById('vrcxStartBtn');
    start.disabled = false;
    start.innerHTML = vrcxStartBtnHtml(false);
    document.getElementById('vrcxPreviewBox').style.display = '';
}

function vrcxStartImport() {
    _vrcxLastDone = null;
    _vrcxLastError = null;
    _vrcxLastProgress = { percent: 5, status: 'Reading database...' };
    document.getElementById('vrcxActionBtns').style.display = 'none';
    document.getElementById('vrcxImportError').style.display = 'none';
    _vrcxSetProgress(5, 'Reading database...');
    document.getElementById('vrcxProgressWrap').style.display = '';
    sendToCS({ action: 'importVrcxStart' });
}

function _vrcxSetProgress(pct, label) {
    document.getElementById('vrcxProgressBar').style.width = pct + '%';
    const progressLabel = document.getElementById('vrcxProgressLabel');
    progressLabel.dataset.rawLabel = label || '';
    progressLabel.textContent = translateVrcxStatus(label || '');
}

function vrcxShowProgress(p) {
    _vrcxLastProgress = p;
    _vrcxSetProgress(p.percent ?? 0, p.status ?? '');
}

function vrcxShowDone(p) {
    _vrcxLastDone = p;
    _vrcxLastError = null;
    _vrcxLastProgress = { percent: 100, status: 'Done' };
    _vrcxSetProgress(100, 'Done');
    setTimeout(() => {
        document.getElementById('vrcxProgressWrap').style.display = 'none';
        document.getElementById('vrcxSuccessDetail').innerHTML =
            `${(p.worlds ?? 0).toLocaleString()} worlds &nbsp;Â·&nbsp; ` +
            `${(p.friends ?? 0).toLocaleString()} friends &nbsp;Â·&nbsp; ` +
            `${(p.timelineJoins ?? 0).toLocaleString()} joins &nbsp;Â·&nbsp; ` +
            `${(p.friendEvents ?? 0).toLocaleString()} friend events &nbsp;Â·&nbsp; ` +
            `${(p.meetEvents ?? 0).toLocaleString()} meets`;
        renderVrcxSuccessDetail(p);
        document.getElementById('vrcxSuccessCard').style.display = '';
        document.getElementById('vrcxDoneBtn').style.display = '';
    }, 400);
}

function vrcxShowError(err) {
    _vrcxLastDone = null;
    _vrcxLastError = err || '';
    _vrcxLastProgress = null;
    document.getElementById('vrcxProgressWrap').style.display = 'none';
    renderVrcxError(err);
    document.getElementById('vrcxImportError').style.display = '';
    document.getElementById('vrcxActionBtns').style.display = 'flex';
    const start = document.getElementById('vrcxStartBtn');
    start.disabled = false;
    start.innerHTML = vrcxStartBtnHtml(true);
}

// === Design Tabs ===

function switchDesignTab(tab, btn) {
    document.getElementById('designTabBackground').style.display = tab === 'background' ? '' : 'none';
    document.getElementById('designTabColors').style.display    = tab === 'colors'     ? '' : 'none';
    document.getElementById('designTabOther').style.display     = tab === 'other'      ? '' : 'none';
    btn.closest('.fd-tabs').querySelectorAll('.fd-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
}

// === Avtrdb Community Support ===

function switchAvtrdbTab(tab, btn) {
    document.getElementById('avtrdbTabSupport').style.display = tab === 'support' ? '' : 'none';
    document.getElementById('avtrdbTabReports').style.display = tab === 'reports' ? '' : 'none';
    btn.closest('.fd-tabs').querySelectorAll('.fd-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
}

const _avtrdbReports = [];
let _avtrdbCollecting = 0;
let _avtrdbCollectTimer = null;
let _avtrdbCollectEnd = 0;

function avtrdbCollecting(count) {
    _avtrdbCollecting += count;
    // Reset 60s countdown on each new batch
    _avtrdbCollectEnd = Date.now() + 60000;
    if (!_avtrdbCollectTimer) {
        _avtrdbCollectTimer = setInterval(() => {
            renderAvtrdbReports();
            if (Date.now() >= _avtrdbCollectEnd) {
                clearInterval(_avtrdbCollectTimer);
                _avtrdbCollectTimer = null;
            }
        }, 1000);
    }
    renderAvtrdbReports();
}

function addAvtrdbReport(count, enqueued, invalid, ticket, type) {
    _avtrdbReports.push({ ts: Date.now(), count, enqueued, invalid, ticket, type: type || 'deletion' });
    // Clear collecting state
    _avtrdbCollecting = 0;
    _avtrdbCollectEnd = 0;
    if (_avtrdbCollectTimer) { clearInterval(_avtrdbCollectTimer); _avtrdbCollectTimer = null; }
    renderAvtrdbReports();
}

function renderAvtrdbReports() {
    const el = document.getElementById('avtrdbReportsList');
    if (!el) return;

    let html = '';

    // Show collecting banner if active
    if (_avtrdbCollecting > 0 && _avtrdbCollectEnd > Date.now()) {
        const secsLeft = Math.max(0, Math.ceil((_avtrdbCollectEnd - Date.now()) / 1000));
        html += `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(var(--accent-rgb,100,140,255),.12);border:1px solid rgba(var(--accent-rgb,100,140,255),.25);border-radius:8px;margin-bottom:10px;">
            <span class="msi" style="font-size:18px;color:var(--accent);">hourglass_top</span>
            <div style="flex:1;">
                <div style="font-size:12px;font-weight:600;color:var(--tx1);">${t('settings.avtrdb.reports.collecting_title', 'Collecting Data')}</div>
                <div style="font-size:11px;color:var(--tx3);margin-top:2px;">${tf('settings.avtrdb.reports.collecting_desc', { count: _avtrdbCollecting, seconds: secsLeft }, `${_avtrdbCollecting} deleted avatar(s) queued, sending in ${secsLeft}s`)}</div>
            </div>
        </div>`;
    }

    if (!_avtrdbReports.length && !html) {
        el.innerHTML = `<div class="empty-msg">${t('settings.avtrdb.reports.empty', 'No reports sent yet this session.')}</div>`;
        return;
    }

    html += _avtrdbReports.slice().reverse().map(r => {
        const isDeletion = r.type === 'deletion';
        const typeLabel = isDeletion
            ? t('settings.avtrdb.reports.type.deletion', 'Mark for deletion')
            : t('settings.avtrdb.reports.type.submitted', 'Submitted Avatar');
        const typeColor = isDeletion ? 'var(--err)' : 'var(--ok)';
        const typeIcon = isDeletion ? 'delete' : 'upload';
        const time = new Date(r.ts || Date.now()).toLocaleTimeString(settingsUiLocale(), { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const summaryParts = [tf('settings.avtrdb.reports.enqueued', { count: r.enqueued }, `${r.enqueued} enqueued`)];
        if (r.invalid > 0) {
            summaryParts.push(tf('settings.avtrdb.reports.invalid', { count: r.invalid }, `${r.invalid} invalid`));
        }
        return `<div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:var(--bg-input);border-radius:8px;margin-bottom:6px;">
        <span style="font-size:11px;color:var(--tx3);white-space:nowrap;">${esc(time)}</span>
        <span class="vrcn-badge" style="font-size:10px;color:${typeColor};flex-shrink:0;"><span class="msi" style="font-size:10px;">${typeIcon}</span> ${esc(typeLabel)}</span>
        <span style="font-size:12px;color:var(--tx1);flex:1;">${esc(summaryParts.join(', '))}</span>
        <button class="vrcn-button-round" style="font-size:11px;padding:4px 10px;" onclick="sendToCS({action:'openUrl',url:'https://avtrdb.com/check_ticket_status/${esc(r.ticket)}'})">
            <span class="msi" style="font-size:13px;">open_in_new</span> ${t('settings.avtrdb.reports.ticket', 'Ticket')}
        </button>
    </div>`;
    }).join('');

    el.innerHTML = html;
}

function rerenderSettingsTranslations() {
    renderFileList();
    renderAvtrdbReports();

    const selectBtn = document.getElementById('vrcxSelectBtn');
    if (selectBtn && selectBtn.style.display !== 'none') {
        selectBtn.innerHTML = vrcxSelectBtnHtml(selectBtn.disabled);
    }

    const startBtn = document.getElementById('vrcxStartBtn');
    const actionBtns = document.getElementById('vrcxActionBtns');
    if (startBtn && actionBtns && actionBtns.style.display !== 'none') {
        startBtn.innerHTML = vrcxStartBtnHtml(!!_vrcxLastError);
    }

    if (_vrcxPreviewData && document.getElementById('vrcxPreviewBox')?.style.display !== 'none') {
        renderVrcxPreviewRows(_vrcxPreviewData);
    }

    if (_vrcxLastProgress && document.getElementById('vrcxProgressWrap')?.style.display !== 'none') {
        _vrcxSetProgress(_vrcxLastProgress.percent ?? 0, _vrcxLastProgress.status ?? '');
    }

    if (_vrcxLastDone && document.getElementById('vrcxSuccessCard')?.style.display !== 'none') {
        renderVrcxSuccessDetail(_vrcxLastDone);
    }

    if (document.getElementById('vrcxImportError')?.style.display !== 'none') {
        renderVrcxError(_vrcxLastError);
    }
}

document.documentElement.addEventListener('languagechange', rerenderSettingsTranslations);
