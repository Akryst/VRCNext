/* === Context Menu Service ===
 * External, self-contained right-click menu with submenu support.
 * Uses event delegation; no modifications to other JS files needed.
 * Entity IDs are extracted from existing onclick attributes via regex.
 */
(function () {
    const menu = document.createElement('div');
    const submenu = document.createElement('div');
    menu.id = 'vn-ctx-menu';
    submenu.id = 'vn-ctx-submenu';
    document.body.appendChild(menu);
    document.body.appendChild(submenu);

    let callbacks = [];
    let confirmState = null; // { idx, timer }
    let submenuTimer = null;

    function cm(key, fallback = '') {
        return typeof t === 'function' ? t(`context_menu.${key}`, fallback) : fallback;
    }

    function copyWithToast(text, toastKey, fallback) {
        navigator.clipboard.writeText(text);
        showToast(true, cm(toastKey, fallback));
    }

    /* Dismiss */
    document.addEventListener('click', e => {
        if (!menu.contains(e.target) && !submenu.contains(e.target)) hideMenu();
    });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') hideMenu();
    });

    /* Main listener */
    document.addEventListener('contextmenu', e => {
        hideMenu();
        const sel = (typeof _textToolsEnabled !== 'undefined' && _textToolsEnabled)
            ? (window.getSelection()?.toString().trim() ?? '')
            : '';
        const copyItem = sel
            ? { icon: 'content_copy', label: 'Copy', action: () => navigator.clipboard.writeText(sel).catch(() => {}) }
            : null;

        let cfg = getMenuConfig(e);
        if (copyItem && cfg) cfg = [copyItem, 'sep', ...cfg];
        else if (copyItem && !cfg) cfg = [copyItem];

        if (!cfg) return;
        e.preventDefault();
        showMenu(e.clientX, e.clientY, cfg);
    });

    /* Submenu hover persistence */
    submenu.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
    submenu.addEventListener('mouseleave', () => {
        submenuTimer = setTimeout(hideSubmenu, 150);
    });

    /* Show / Hide */
    function showMenu(x, y, items) {
        callbacks = [];
        menu.innerHTML = buildHTML(items);

        menu.style.visibility = 'hidden';
        menu.style.display = 'block';
        const mw = menu.offsetWidth;
        const mh = menu.offsetHeight;
        menu.style.visibility = '';

        const z = (typeof _guiZoom !== 'undefined' ? _guiZoom : 1);
        const vw = window.innerWidth / z;
        const vh = window.innerHeight / z;
        const lx = x / z;
        const ly = y / z;
        menu.style.left = ((lx + mw > vw - 6) ? Math.max(4, lx - mw) : lx) + 'px';
        menu.style.top = ((ly + mh > vh - 6) ? Math.max(4, ly - mh) : ly) + 'px';

        menu.querySelectorAll('.vn-ctx-item[data-idx]:not(.has-sub)').forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                submenuTimer = setTimeout(hideSubmenu, 100);
            });
            btn.addEventListener('click', e => {
                e.stopPropagation();
                const item = callbacks[+btn.dataset.idx];
                if (!item) return;
                if (item.confirm) handleConfirm(btn, item, +btn.dataset.idx);
                else {
                    item.action();
                    hideMenu();
                }
            });
        });

        menu.querySelectorAll('.vn-ctx-item.has-sub').forEach(btn => {
            const open = () => {
                clearTimeout(submenuTimer);
                hideSubmenu();
                callbacks[+btn.dataset.idx]?.submenuFn?.(btn);
            };
            btn.addEventListener('mouseenter', open);
            btn.addEventListener('click', e => {
                e.stopPropagation();
                open();
            });
            btn.addEventListener('mouseleave', () => {
                submenuTimer = setTimeout(hideSubmenu, 150);
            });
        });
    }

    function hideMenu() {
        hideSubmenu();
        if (confirmState) {
            clearTimeout(confirmState.timer);
            confirmState = null;
        }
        menu.style.display = 'none';
        menu.innerHTML = '';
        callbacks = [];
    }

    function hideSubmenu() {
        clearTimeout(submenuTimer);
        submenu.style.display = 'none';
        submenu.innerHTML = '';
    }

    /* Favorites submenu */
    function showFavGroupSubmenu(worldId, parentBtn) {
        const groups = (typeof favWorldGroups !== 'undefined') ? favWorldGroups : [];

        if (groups.length === 0) {
            submenu.innerHTML = `<div class="vn-ctx-loading">
                <span class="msi">hourglass_empty</span><span>${esc(cm('loading_groups', 'Loading groups...'))}</span>
            </div>`;
            positionSubmenu(parentBtn);
            sendToCS({ action: 'vrcGetFavoriteWorlds' });
            let attempts = 0;
            const retry = setInterval(() => {
                const g = (typeof favWorldGroups !== 'undefined') ? favWorldGroups : [];
                if (g.length > 0 || ++attempts > 15) {
                    clearInterval(retry);
                    if (g.length > 0 && submenu.style.display !== 'none') showFavGroupSubmenu(worldId, parentBtn);
                }
            }, 300);
            return;
        } else {
            submenu.innerHTML = groups.map(g => {
                const count = (typeof favWorldsData !== 'undefined')
                    ? favWorldsData.filter(fw => fw.favoriteGroup === g.name).length
                    : 0;
                return `<button class="vn-ctx-item"
                    data-fav-name="${g.name}" data-fav-type="${g.type}" data-wid="${worldId}">
                    <span class="msi" style="font-size:14px;">bookmark_border</span>
                    <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                    <span class="vn-ctx-count">${count}</span>
                </button>`;
            }).join('');

            submenu.querySelectorAll('[data-fav-name]').forEach(btn => {
                btn.addEventListener('click', e => {
                    e.stopPropagation();
                    sendToCS({
                        action: 'vrcAddWorldFavorite',
                        worldId: btn.dataset.wid,
                        groupName: btn.dataset.favName,
                        groupType: btn.dataset.favType,
                        oldFvrtId: ''
                    });
                    hideMenu();
                });
                btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
            });
        }

        positionSubmenu(parentBtn);
    }

    function showMoveToGroupSubmenu(worldId, favEntry, parentBtn) {
        const groups = (typeof favWorldGroups !== 'undefined') ? favWorldGroups : [];
        submenu.innerHTML = groups.map(g => {
            const isCurrent = g.name === favEntry.favoriteGroup;
            const count = (typeof favWorldsData !== 'undefined')
                ? favWorldsData.filter(fw => fw.favoriteGroup === g.name).length
                : 0;
            const iconEl = isCurrent
                ? `<span class="msi" style="font-size:14px;color:var(--accent);">check_circle</span>`
                : `<span class="msi" style="font-size:14px;">drive_file_move</span>`;
            return `<button class="vn-ctx-item${isCurrent ? ' ci-group-selected' : ''}"
                data-move-name="${esc(g.name)}" data-move-type="${esc(g.type)}" data-wid="${esc(worldId)}" data-old-fvrt="${esc(favEntry.favoriteId)}" data-is-current="${isCurrent}">
                ${iconEl}
                <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                <span class="vn-ctx-count">${count}</span>
            </button>`;
        }).join('');
        submenu.querySelectorAll('[data-move-name]').forEach(btn => {
            btn.addEventListener('click', e => {
                e.stopPropagation();
                if (btn.dataset.isCurrent === 'true') { hideMenu(); return; }
                sendToCS({
                    action: 'vrcAddWorldFavorite',
                    worldId: btn.dataset.wid,
                    groupName: btn.dataset.moveName,
                    groupType: btn.dataset.moveType,
                    oldFvrtId: btn.dataset.oldFvrt
                });
                hideMenu();
            });
            btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
        });
        positionSubmenu(parentBtn);
    }

    function positionSubmenu(parentBtn) {
        const rect = parentBtn.getBoundingClientRect();
        const z = (typeof _guiZoom !== 'undefined' ? _guiZoom : 1);
        const vw = window.innerWidth / z;
        const vh = window.innerHeight / z;
        submenu.style.visibility = 'hidden';
        submenu.style.display = 'block';
        const sw = submenu.offsetWidth;
        const sh = submenu.offsetHeight;
        submenu.style.visibility = '';
        let left = rect.right / z + 4;
        if (left + sw > vw - 6) left = rect.left / z - sw - 4;
        let top = rect.top / z;
        if (top + sh > vh - 6) top = Math.max(4, vh - sh - 6);
        submenu.style.left = left + 'px';
        submenu.style.top = top + 'px';
    }

    /* Two-step confirm */
    function handleConfirm(btn, item, idx) {
        if (confirmState && confirmState.idx === idx) {
            clearTimeout(confirmState.timer);
            confirmState = null;
            item.action();
            hideMenu();
        } else {
            if (confirmState) {
                clearTimeout(confirmState.timer);
                resetConfirmBtn(confirmState.idx);
            }
            btn.classList.add('confirm-pending');
            btn.querySelector('.vn-ctx-label').textContent = cm('confirm', 'Confirm?');
            const timer = setTimeout(() => {
                if (confirmState?.idx === idx) {
                    resetConfirmBtn(idx);
                    confirmState = null;
                }
            }, 3500);
            confirmState = { idx, timer };
        }
    }

    function resetConfirmBtn(idx) {
        const btn = menu.querySelector(`.vn-ctx-item[data-idx="${idx}"]`);
        if (!btn) return;
        btn.classList.remove('confirm-pending');
        btn.querySelector('.vn-ctx-label').textContent = callbacks[idx]?.label || '';
    }

    /* HTML builder */
    function buildHTML(items) {
        return items.map(item => {
            if (item === 'sep') return '<div class="vn-ctx-sep"></div>';
            const idx = callbacks.length;
            callbacks.push(item);
            const hasSub = !!item.submenuFn;
            const cls = [item.danger ? 'danger' : '', hasSub ? 'has-sub' : ''].filter(Boolean).join(' ');
            const arrow = hasSub ? '<span class="msi vn-ctx-arrow">chevron_right</span>' : '';
            const check = item.checked ? '<span class="msi vn-ctx-check">check</span>' : '';
            const iconEl = item.dotColor
                ? `<span class="vn-ctx-dot" style="background:${item.dotColor}"></span>`
                : `<span class="msi">${item.icon}</span>`;
            return `<button class="vn-ctx-item${cls ? ' ' + cls : ''}" data-idx="${idx}">
                ${iconEl}
                <span class="vn-ctx-label">${esc(item.label)}</span>${check}${arrow}
            </button>`;
        }).join('');
    }

    /* Entity detection */
    function getMenuConfig(e) {
        const el = e.target;

        if (el.id === 'netCanvas' && typeof _netGraph !== 'undefined' && _netGraph) {
            const rect = el.getBoundingClientRect();
            const wx = (e.clientX - rect.left - _netGraph.tx) / _netGraph.scale;
            const wy = (e.clientY - rect.top - _netGraph.ty) / _netGraph.scale;
            const hit = _netGraph._hitTest(wx, wy);
            if (hit >= 0) {
                const nd = _netGraph.nodes[hit];
                if (nd?.id) return buildFriendItems(nd.id);
            }
            return null;
        }

        if (el.closest('.nav-btn[data-nav="dashboard"]')) {
            return [{ icon: 'dashboard_customize', label: cm('dash_layout', 'Edit Dashboard'), action: () => openDashLayoutEditor() }];
        }

        if (el.closest('#vrcProfileArea') && (typeof currentVrcUser !== 'undefined') && currentVrcUser) {
            return buildSelfItems();
        }

        const libCard = el.closest('.lib-card, .dash-photo-item');
        if (libCard) {
            const path = libCard.dataset.path || '';
            const url = libCard.dataset.url || '';
            const type = libCard.dataset.type || 'image';
            const name = libCard.dataset.name || '';
            if (path) return buildLibCardItems(path, url, type, name);
        }

        const groupCard = el.closest('#myGroupsGrid .vrcn-content-card, #dashGroupActivityGrid .dash-group-card');
        if (groupCard) {
            const id = extractId(groupCard, /openGroupDetail\('([^']+)'\)/);
            if (id) return buildGroupItems(id);
        }

        const myInstCard = el.closest('#dashMyInstances .vrcn-content-card');
        if (myInstCard) {
            const loc = myInstCard.dataset.location;
            if (loc) return buildMyInstanceItems(loc);
        }

        const dashWorld = el.closest('#dashFavWorlds .vrcn-content-card, #dashDiscoveryGrid .vrcn-content-card, #dashFavWorldsShelf .vrcn-content-card, #dashRecentlyVisitedShelf .vrcn-content-card, #dashPopularWorldsShelf .vrcn-content-card, #dashActiveWorldsShelf .vrcn-content-card, #dashFriendLocSmallShelf .dash-floc-card');
        if (dashWorld) {
            const id = extractId(dashWorld, /openWorld(?:Search)?Detail\('([^']+)'\)/);
            if (id) return buildWorldItems(id);
        }

        const worldCard = el.closest('#favWorldsGrid .vrcn-content-card, #worldSearchArea .vrcn-content-card, #worldMineGrid .vrcn-content-card, #fdContentWorlds .vrcn-content-card');
        if (worldCard) {
            const id = extractId(worldCard, /openWorldSearchDetail\('([^']+)'\)/) || worldCard.dataset.wid;
            if (id) return buildWorldItems(id);
        }

        const avatarCard = el.closest('.av-card');
        if (avatarCard) {
            const id = (avatarCard.getAttribute('onclick') || '').match(/selectAvatar\('([^']+)'\)/)?.[1] || avatarCard.dataset.avid;
            if (id) return buildAvatarItems(id);
        }

        const bannedCard = el.closest('#gdTabBanned .vrcn-profile-item');
        if (bannedCard && window._currentGroupDetail?.canBan) {
            const id = extractId(bannedCard, /openFriendDetail\('([^']+)'\)/);
            if (id) {
                return [
                    {
                        icon: 'lock_open',
                        label: cm('group.unban_member', 'Unban Member'),
                        action: () => sendToCS({ action: 'vrcUnbanGroupMember', groupId: window._currentGroupDetail.id, userId: id })
                    },
                    'sep',
                    ...buildFriendItems(id)
                ];
            }
        }

        const memberCard = el.closest('#gdTabMembers .vrcn-profile-item, #gdTabRoles .vrcn-profile-item');
        if (memberCard && window._currentGroupDetail) {
            const id = extractId(memberCard, /openFriendDetail\('([^']+)'\)/);
            if (id) {
                const memberRoleIds = (window._gdMemberRoleIds && window._gdMemberRoleIds[id]) || [];
                return buildGroupMemberItems(id, window._currentGroupDetail, memberRoleIds);
            }
        }

        const friendCard = el.closest('.vrc-friend-card, .vrcn-profile-item, .inst-user-row, .iim-user-tr, .dash-feed-card, .fav-friend-card, .s-card-h');
        if (friendCard) {
            const id = extractId(friendCard, /openFriendDetail\('([^']+)'\)/);
            if (id) return buildFriendItems(id);
        }

        const instanceCard = el.closest('#vrcInstanceArea .inst-card');
        if (instanceCard) {
            const wid = (typeof currentInstanceData !== 'undefined') && currentInstanceData?.worldId;
            if (wid && !currentInstanceData.empty && !currentInstanceData.error) return buildWorldItems(wid);
        }

        return null;
    }

    function extractId(el, pattern) {
        return (el.getAttribute('onclick') || '').match(pattern)?.[1] || null;
    }

    /* Menu item builders */
    function buildGroupItems(id) {
        const g = (typeof myGroups !== 'undefined') && myGroups.find(x => x.id === id);
        const canPost = g && g.canPost === true;
        const canEvent = g && g.canEvent === true;
        const isRep = g && g.isRepresenting === true;
        const items = [
            { icon: 'open_in_new', label: cm('group.open_details', 'Open Details'), action: () => openGroupDetail(id) },
            { icon: 'share', label: cm('group.share', 'Share Group'), action: () => copyWithToast('https://vrchat.com/home/group/' + id, 'group.share_copied', 'Group link copied to clipboard') },
            'sep',
        ];
        if (canPost) items.push({ icon: 'edit_note', label: cm('group.post', 'Post'), action: () => openGroupPostModal(id) });
        if (canEvent) items.push({ icon: 'event', label: cm('group.events', 'Events'), action: () => openGroupEventModal(id) });
        if (canPost || canEvent) items.push('sep');
        items.push({ icon: 'shield_person', label: cm('group.represent', 'Represent this group'), action: () => sendToCS({ action: 'vrcRepresentGroup', groupId: id }), disabled: isRep });
        items.push('sep');
        items.push({ icon: 'logout', label: cm('group.leave', 'Leave Group'), action: () => sendToCS({ action: 'vrcLeaveGroup', groupId: id }), danger: true, confirm: true });
        return items;
    }

    function buildGroupMemberItems(userId, grpCtx, memberRoleIds = []) {
        const modItems = [];
        if (grpCtx.canKick) {
            modItems.push({
                icon: 'person_remove',
                label: cm('group.kick_member', 'Kick from group'),
                danger: true,
                confirm: true,
                action: () => sendToCS({ action: 'vrcKickGroupMember', groupId: grpCtx.id, userId })
            });
        }
        if (grpCtx.canBan) {
            modItems.push({
                icon: 'block',
                label: cm('group.ban_member', 'Ban from group'),
                danger: true,
                confirm: true,
                action: () => sendToCS({ action: 'vrcBanGroupMember', groupId: grpCtx.id, userId })
            });
        }
        if (grpCtx.canAssignRoles) {
            const assignable = (grpCtx.roles || []).filter(r => !(r.permissions || []).includes('*'));
            if (assignable.length > 0) {
                modItems.push({
                    icon: 'badge',
                    label: cm('group.assign_role', 'Assign Role'),
                    submenuFn: btn => showRoleAssignSubmenu(userId, grpCtx, memberRoleIds, btn)
                });
            }
        }
        const friendItems = buildFriendItems(userId);
        if (modItems.length > 0) return [...modItems, 'sep', ...friendItems];
        return friendItems;
    }

    function showRoleAssignSubmenu(userId, grpCtx, memberRoleIds, parentBtn) {
        const roles = (grpCtx.roles || []).filter(r => !(r.permissions || []).includes('*'));
        submenu.innerHTML = roles.map(r => {
            const hasRole = memberRoleIds.includes(r.id);
            return `<button class="vn-ctx-item" data-role-id="${esc(r.id)}" data-group-id="${esc(grpCtx.id)}" data-user-id="${esc(userId)}" data-has-role="${hasRole}">
                <span class="msi" style="font-size:14px;color:${hasRole ? 'var(--ok, #4caf50)' : 'inherit'};">${hasRole ? 'check_circle' : 'badge'}</span>
                <span class="vn-ctx-label">${esc(r.name)}</span>
            </button>`;
        }).join('');
        submenu.querySelectorAll('[data-role-id]').forEach(btn => {
            btn.addEventListener('click', e => {
                e.stopPropagation();
                const action = btn.dataset.hasRole === 'true' ? 'vrcRemoveGroupMemberRole' : 'vrcAddGroupMemberRole';
                sendToCS({ action, groupId: btn.dataset.groupId, userId: btn.dataset.userId, roleId: btn.dataset.roleId });
                hideMenu();
            });
            btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
        });
        positionSubmenu(parentBtn);
    }

    function showAvFavGroupSubmenu(avatarId, parentBtn) {
        const groups = (typeof favAvatarGroups !== 'undefined') ? favAvatarGroups : [];
        if (groups.length === 0) {
            submenu.innerHTML = `<div class="vn-ctx-loading"><span class="msi">hourglass_empty</span><span>${esc(cm('loading_groups', 'Loading groups...'))}</span></div>`;
            positionSubmenu(parentBtn);
            sendToCS({ action: 'vrcGetAvatars', filter: 'favorites' });
            let attempts = 0;
            const retry = setInterval(() => {
                const g = (typeof favAvatarGroups !== 'undefined') ? favAvatarGroups : [];
                if (g.length > 0 || ++attempts > 15) {
                    clearInterval(retry);
                    if (g.length > 0 && submenu.style.display !== 'none') showAvFavGroupSubmenu(avatarId, parentBtn);
                }
            }, 300);
            return;
        } else {
            submenu.innerHTML = groups.map(g => {
                const count = (typeof favAvatarsData !== 'undefined') ? favAvatarsData.filter(a => a.favoriteGroup === g.name).length : 0;
                const isVrcPlus = g.name !== 'avatars1';
                return `<button class="vn-ctx-item" data-av-fav-name="${esc(g.name)}" data-av-fav-type="${esc(g.type)}" data-avid="${esc(avatarId)}">
                    <span class="msi" style="font-size:14px;">bookmark_border</span>
                    <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                    ${isVrcPlus ? '<span class="vrcn-badge vrcplus" style="font-size:10px;padding:1px 4px;">VRC+</span>' : ''}
                    <span class="vn-ctx-count">${count}</span>
                </button>`;
            }).join('');
            submenu.querySelectorAll('[data-av-fav-name]').forEach(btn => {
                btn.addEventListener('click', e => {
                    e.stopPropagation();
                    sendToCS({ action: 'vrcAddAvatarFavorite', avatarId: btn.dataset.avid, groupName: btn.dataset.avFavName, groupType: btn.dataset.avFavType, oldFvrtId: '' });
                    hideMenu();
                });
                btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
            });
        }
        positionSubmenu(parentBtn);
    }

    function showAvMoveToGroupSubmenu(avatarId, favEntry, parentBtn) {
        const groups = (typeof favAvatarGroups !== 'undefined') ? favAvatarGroups : [];
        submenu.innerHTML = groups.map(g => {
            const isCurrent = g.name === favEntry.favoriteGroup;
            const count = (typeof favAvatarsData !== 'undefined') ? favAvatarsData.filter(a => a.favoriteGroup === g.name).length : 0;
            const iconEl = isCurrent
                ? `<span class="msi" style="font-size:14px;color:var(--accent);">check_circle</span>`
                : `<span class="msi" style="font-size:14px;">drive_file_move</span>`;
            const isVrcPlus = g.name !== 'avatars1';
            return `<button class="vn-ctx-item${isCurrent ? ' ci-group-selected' : ''}"
                data-av-move-name="${esc(g.name)}" data-av-move-type="${esc(g.type)}" data-avid="${esc(avatarId)}" data-old-fvrt="${esc(favEntry.favoriteId)}" data-is-current="${isCurrent}">
                ${iconEl}
                <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                ${isVrcPlus ? '<span class="vrcn-badge vrcplus" style="font-size:10px;padding:1px 4px;">VRC+</span>' : ''}
                <span class="vn-ctx-count">${count}</span>
            </button>`;
        }).join('');
        submenu.querySelectorAll('[data-av-move-name]').forEach(btn => {
            btn.addEventListener('click', e => {
                e.stopPropagation();
                if (btn.dataset.isCurrent === 'true') { hideMenu(); return; }
                sendToCS({ action: 'vrcAddAvatarFavorite', avatarId: btn.dataset.avid, groupName: btn.dataset.avMoveName, groupType: btn.dataset.avMoveType, oldFvrtId: btn.dataset.oldFvrt });
                hideMenu();
            });
            btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
        });
        positionSubmenu(parentBtn);
    }

    function showAvEditModeGroupSubmenu(parentBtn) {
        const groups = (typeof favAvatarGroups !== 'undefined') ? favAvatarGroups : [];
        submenu.innerHTML = groups.map(g => {
            const count = (typeof favAvatarsData !== 'undefined') ? favAvatarsData.filter(a => a.favoriteGroup === g.name).length : 0;
            const isVrcPlus = g.name !== 'avatars1';
            return `<button class="vn-ctx-item" data-av-edit-move-name="${esc(g.name)}" data-av-edit-move-type="${esc(g.type)}">
                <span class="msi" style="font-size:14px;">folder</span>
                <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                ${isVrcPlus ? '<span class="vrcn-badge vrcplus" style="font-size:10px;padding:1px 4px;">VRC+</span>' : ''}
                <span class="vn-ctx-count">${count}</span>
            </button>`;
        }).join('');
        submenu.querySelectorAll('[data-av-edit-move-name]').forEach(btn => {
            btn.addEventListener('click', e => {
                e.stopPropagation();
                avEditMoveSelected(btn.dataset.avEditMoveName, btn.dataset.avEditMoveType);
                hideMenu();
            });
            btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
        });
        positionSubmenu(parentBtn);
    }

    function buildAvatarItems(id) {
        // Edit mode: auto-select right-clicked avatar and show only batch-action items
        if (typeof _avEditMode !== 'undefined' && _avEditMode) {
            if (!_avEditSelected.has(id)) {
                _avEditSelected.add(id);
                if (typeof filterFavAvatars === 'function') filterFavAvatars();
                else if (typeof updateAvEditBar === 'function') updateAvEditBar();
            }
            return [
                { icon: 'drive_file_move', label: cm('avatar.move_to_category', 'Move to Category'), submenuFn: btn => showAvEditModeGroupSubmenu(btn) },
                { icon: 'star_border', label: cm('avatar.remove_favorites', 'Remove from Favorites'), action: () => avEditRemoveSelected(), danger: true, confirm: true },
            ];
        }

        const favEntry = (typeof favAvatarsData !== 'undefined') && favAvatarsData.find(a => a.id === id);
        const items = [
            { icon: 'info', label: cm('avatar.show', 'Show Avatar'), action: () => openAvatarDetail(id) },
            { icon: 'share', label: cm('avatar.share', 'Share Avatar'), action: () => copyWithToast('https://vrchat.com/home/avatar/' + id, 'avatar.share_copied', 'Avatar link copied to clipboard') },
            { icon: 'checkroom', label: cm('avatar.use', 'Use Avatar'), action: () => sendToCS({ action: 'vrcSelectAvatar', avatarId: id }) },
            'sep',
            { icon: 'style', label: cm('avatar.similar', 'Similar Avatars'), action: () => { showTab(4); setAvatarFilter('search'); setTimeout(() => { const inp = document.getElementById('avatarSearchInput'); if (inp) { inp.value = 'similar: ' + id; doAvatarSearch(); } }, 100); } },
            'sep',
        ];
        if (favEntry) {
            items.push({ icon: 'star_border', label: cm('avatar.remove_favorites', 'Remove from Favorites'), action: () => removeAvatarFavorite(id, favEntry.favoriteId) });
            items.push({ icon: 'drive_file_move', label: cm('avatar.move_to_category', 'Move to Category'), submenuFn: btn => showAvMoveToGroupSubmenu(id, favEntry, btn) });
        } else {
            items.push({ icon: 'star', label: cm('avatar.add_favorites', 'Add to Favorites'), submenuFn: btn => showAvFavGroupSubmenu(id, btn) });
        }
        return items;
    }

    function buildMyInstanceItems(loc) {
        const inst = (typeof _myInstancesData !== 'undefined') && _myInstancesData.find(i => i.location === loc);
        const worldId = inst?.worldId || '';
        const wn = inst?.worldName || '';
        const wt = inst?.worldThumb || '';
        const it = inst?.instanceType || '';
        const favEntry = (typeof favWorldsData !== 'undefined') && favWorldsData.find(fw => fw.id === worldId);
        const items = [];
        if (loc) {
            items.push({ icon: 'person_add', label: cm('instance.invite_friends', 'Invite Friends'), action: () => openInviteModalForLocation(loc, wn, wt, it) });
            items.push({ icon: 'close', label: cm('instance.close', 'Close Instance'), action: () => removeMyInstance(loc), danger: true, confirm: true });
            items.push('sep');
        }
        items.push({ icon: 'open_in_new', label: cm('world.open_details', 'Open Details'), action: () => openWorldSearchDetail(worldId) });
        items.push({ icon: 'add_circle_outline', label: cm('world.create_instance', 'Create Instance'), action: () => createWorldInstance(worldId) });
        items.push({ icon: 'share', label: cm('world.share', 'Share World'), action: () => copyWithToast('https://vrchat.com/home/world/' + worldId, 'world.share_copied', 'World link copied to clipboard') });
        items.push({ icon: 'home', label: cm('world.set_home', 'Set as Home'), action: () => sendToCS({ action: 'vrcSetHomeWorld', worldId }), confirm: true });
        items.push('sep');
        if (favEntry) {
            items.push({ icon: 'star_border', label: cm('world.remove_favorites', 'Remove from Favorites'), action: () => removeWorldFavorite(worldId, favEntry.favoriteId) });
            const otherGroups = (typeof favWorldGroups !== 'undefined') ? favWorldGroups.filter(g => g.name !== favEntry.favoriteGroup) : [];
            if (otherGroups.length > 0) {
                items.push({ icon: 'drive_file_move', label: cm('world.move_to_category', 'Move to Category'), submenuFn: btn => showMoveToGroupSubmenu(worldId, favEntry, btn) });
            }
        } else {
            items.push({ icon: 'star', label: cm('world.add_favorites', 'Add to Favorites'), submenuFn: btn => showFavGroupSubmenu(worldId, btn) });
        }
        return items;
    }

    function showEditModeGroupSubmenu(parentBtn) {
        const groups = (typeof favWorldGroups !== 'undefined') ? favWorldGroups : [];
        submenu.innerHTML = groups.map(g => {
            const count = (typeof favWorldsData !== 'undefined')
                ? favWorldsData.filter(fw => fw.favoriteGroup === g.name).length
                : 0;
            const isVrcPlus = g.type === 'vrcPlusWorld';
            return `<button class="vn-ctx-item"
                data-edit-move-name="${esc(g.name)}" data-edit-move-type="${esc(g.type)}">
                <span class="msi" style="font-size:14px;">folder</span>
                <span class="vn-ctx-label">${esc(g.displayName || g.name)}</span>
                ${isVrcPlus ? '<span class="vrcn-badge vrcplus" style="font-size:10px;padding:1px 4px;">VRC+</span>' : ''}
                <span class="vn-ctx-count">${count}</span>
            </button>`;
        }).join('');
        submenu.querySelectorAll('[data-edit-move-name]').forEach(btn => {
            btn.addEventListener('click', e => {
                e.stopPropagation();
                worldEditMoveSelected(btn.dataset.editMoveName, btn.dataset.editMoveType);
                hideMenu();
            });
            btn.addEventListener('mouseenter', () => clearTimeout(submenuTimer));
        });
        positionSubmenu(parentBtn);
    }

    function buildWorldItems(id) {
        // Edit mode: auto-select right-clicked world and show only batch-action items
        if (typeof _worldEditMode !== 'undefined' && _worldEditMode) {
            if (!_worldEditSelected.has(id)) {
                _worldEditSelected.add(id);
                if (typeof filterFavWorlds === 'function') filterFavWorlds();
                else if (typeof updateWorldEditBar === 'function') updateWorldEditBar();
            }
            return [
                { icon: 'drive_file_move', label: cm('world.move_to_category', 'Move to Category'), submenuFn: btn => showEditModeGroupSubmenu(btn) },
                { icon: 'star_border', label: cm('world.remove_favorites', 'Remove from Favorites'), action: () => worldEditRemoveSelected(), danger: true, confirm: true },
            ];
        }

        const favEntry = (typeof favWorldsData !== 'undefined') && favWorldsData.find(fw => fw.id === id);
        const items = [
            { icon: 'open_in_new', label: cm('world.open_details', 'Open Details'), action: () => openWorldSearchDetail(id) },
            { icon: 'add_circle_outline', label: cm('world.create_instance', 'Create Instance'), action: () => createWorldInstance(id) },
            { icon: 'share', label: cm('world.share', 'Share World'), action: () => copyWithToast('https://vrchat.com/home/world/' + id, 'world.share_copied', 'World link copied to clipboard') },
            { icon: 'home', label: cm('world.set_home', 'Set as Home'), action: () => sendToCS({ action: 'vrcSetHomeWorld', worldId: id }), confirm: true },
            'sep',
        ];
        if (favEntry) {
            items.push({ icon: 'star_border', label: cm('world.remove_favorites', 'Remove from Favorites'), action: () => removeWorldFavorite(id, favEntry.favoriteId) });
            const otherGroups = (typeof favWorldGroups !== 'undefined') ? favWorldGroups.filter(g => g.name !== favEntry.favoriteGroup) : [];
            if (otherGroups.length > 0) {
                items.push({ icon: 'drive_file_move', label: cm('world.move_to_category', 'Move to Category'), submenuFn: btn => showMoveToGroupSubmenu(id, favEntry, btn) });
            }
        } else {
            items.push({ icon: 'star', label: cm('world.add_favorites', 'Add to Favorites'), submenuFn: btn => showFavGroupSubmenu(id, btn) });
        }
        return items;
    }

    function buildFriendItems(id) {
        const items = [
            { icon: 'person', label: cm('friend.view_profile', 'View Profile'), action: () => openFriendDetail(id) },
            { icon: 'share', label: cm('friend.share_profile', 'Share Profile'), action: () => copyWithToast('https://vrchat.com/home/user/' + id, 'friend.share_copied', 'Profile link copied to clipboard') },
        ];

        const f = (typeof vrcFriendsData !== 'undefined') && vrcFriendsData.find(x => x.id === id);
        if (f) {
            const loc = f.location || '';
            const { instanceType } = parseFriendLocation(loc);
            const isInWorld = loc && loc !== 'offline' && loc !== 'private' && loc !== 'traveling';
            const joinable = ['public', 'friends', 'friends+', 'hidden', 'group-public', 'group-plus', 'group-members', 'group'];
            const canJoin = isInWorld && joinable.includes(instanceType);
            const canRequestInvite = instanceType === 'invite_plus';
            const myInInstance = (typeof currentInstanceData !== 'undefined')
                && currentInstanceData && currentInstanceData.location
                && !currentInstanceData.empty && !currentInstanceData.error;

            const actionItems = [];
            if (canJoin) actionItems.push({ icon: 'login', label: cm('friend.join', 'Join'), action: () => friendAction('join', loc, id) });
            if (canRequestInvite) actionItems.push({ icon: 'mail', label: cm('friend.request_invite', 'Request Invite'), action: () => friendAction('requestInvite', loc, id) });
            if (myInInstance) {
                const hasVrcPlus = Array.isArray(currentVrcUser?.tags) && currentVrcUser.tags.includes('system_supporter');
                actionItems.push({ icon: 'send', label: cm('friend.invite', 'Invite'), action: () => sendToCS({ action: 'vrcInviteFriend', userId: id }) });
                actionItems.push({ icon: 'forward_to_inbox', label: cm('friend.invite_message', 'Invite with Message'), action: () => openFriendInviteModal(id, f.displayName || id, 'message') });
                if (hasVrcPlus) actionItems.push({ icon: 'add_photo_alternate', label: cm('friend.invite_image', 'Invite with Image'), action: () => openFriendInviteModal(id, f.displayName || id, 'photo') });
            }
            actionItems.push({ icon: 'waving_hand', label: cm('friend.boop', 'Boop!'), action: () => { if (typeof msgrRegisterBoopSent === 'function') msgrRegisterBoopSent(id); sendToCS({ action: 'vrcBoop', userId: id }); } });
            actionItems.push({ icon: 'chat', label: cm('friend.messenger', 'Messenger'), action: () => openMessenger(id, f.displayName || id, f.image || '', f.status || '', f.statusDescription || '') });
            if (actionItems.length) {
                items.push('sep');
                actionItems.forEach(i => items.push(i));
            }
        }

        if (f) {
            const isFav = Array.isArray(favFriendsData) && favFriendsData.some(x => x.favoriteId === id);
            const favEntry = isFav ? favFriendsData.find(x => x.favoriteId === id) : null;
            items.push('sep');
            items.push(isFav
                ? { icon: 'star_border', label: cm('friend.unfavorite', 'Unfavorite'), action: () => sendToCS({ action: 'vrcRemoveFavoriteFriend', userId: id, fvrtId: favEntry?.fvrtId || '' }) }
                : { icon: 'star', label: cm('friend.favorite', 'Favorite'), action: () => sendToCS({ action: 'vrcAddFavoriteFriend', userId: id }) }
            );

            const isMuted = Array.isArray(mutedData) && mutedData.some(x => x.targetUserId === id);
            const isBlocked = Array.isArray(blockedData) && blockedData.some(x => x.targetUserId === id);
            items.push('sep');
            items.push(isMuted
                ? { icon: 'mic', label: cm('friend.unmute', 'Unmute'), action: () => sendToCS({ action: 'vrcUnmute', userId: id }) }
                : { icon: 'mic_off', label: cm('friend.mute', 'Mute'), action: () => sendToCS({ action: 'vrcMute', userId: id }) }
            );
            items.push(isBlocked
                ? { icon: 'lock_open', label: cm('friend.unblock', 'Unblock'), action: () => sendToCS({ action: 'vrcUnblock', userId: id }) }
                : { icon: 'block', label: cm('friend.block', 'Block'), action: () => sendToCS({ action: 'vrcBlock', userId: id }), danger: true, confirm: true }
            );
            items.push({ icon: 'person_remove', label: cm('friend.unfriend', 'Unfriend'), action: () => sendToCS({ action: 'vrcUnfriend', userId: id }), danger: true, confirm: true });
        } else {
            items.push('sep');
            items.push({ icon: 'person_add', label: cm('friend.send_request', 'Send Friend Request'), action: () => sendToCS({ action: 'vrcSendFriendRequest', userId: id }) });
        }
        return items;
    }

    function buildLibCardItems(path, url, type, name) {
        const isFav = (typeof favorites !== 'undefined') && favorites.has(path);
        const isHidden = (typeof hiddenMedia !== 'undefined') && hiddenMedia.has(path);
        const items = [
            { icon: 'content_copy', label: cm('library.copy', 'Copy to Clipboard'), action: () => copyToClipboard(url, path, type) },
        ];
        if (type === 'image') {
            items.push({ icon: 'wallpaper', label: cm('library.set_background', 'Set as Background'), action: () => setLibItemAsDashBg(path) });
        }
        items.push('sep');
        items.push(isFav
            ? { icon: 'star_border', label: cm('library.remove_favorite', 'Remove Favorite'), action: () => toggleFavorite(path) }
            : { icon: 'star', label: cm('library.favorite', 'Favorite'), action: () => toggleFavorite(path) }
        );
        items.push(isHidden
            ? { icon: 'visibility', label: cm('library.unhide', 'Unhide'), action: () => toggleHidden(path) }
            : { icon: 'visibility_off', label: cm('library.hide', 'Hide'), action: () => toggleHidden(path) }
        );
        items.push('sep');
        items.push({ icon: 'delete', label: cm('library.delete', 'Delete'), danger: true, action: () => showDeleteModal(path, name) });
        return items;
    }

    function buildSelfItems() {
        const curStatus = currentVrcUser?.status || 'active';
        const items = [
            { icon: 'manage_accounts', label: cm('friend.view_profile', 'View Profile'), action: () => openMyProfileModal() },
            'sep',
        ];
        STATUS_LIST.forEach(s => {
            items.push({
                dotColor: s.color,
                label: t(s.labelKey || '', s.label),
                checked: curStatus === s.key,
                action: () => sendToCS({ action: 'vrcUpdateStatus', status: s.key, statusDescription: currentVrcUser?.statusDescription || '' }),
            });
        });
        return items;
    }
}());
